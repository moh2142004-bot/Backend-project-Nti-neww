# Project Idea Research & Planning

## Project Name

Smart Hospital Management System

## Project Description

A hospital management system that allows patients to book appointments with
doctors, while doctors manage their profiles and availability, and
administrators manage users and system data.

- **Problem it solves:** replaces manual, paper-based scheduling between
  patients and doctors with a centralized digital system.
- **Target users:** patients looking to book appointments, doctors managing
  their schedule and profile, and an admin who oversees the platform.
- **Main purpose:** make booking and managing medical appointments faster,
  organized, and accessible from anywhere.

## User Roles

| Role    | Permissions                                            |
| ------- | -------------------------------------------------------- |
| Admin   | Manage users, manage doctors, manage appointments         |
| Doctor  | Manage own profile, view/manage own appointments          |
| Patient | Book appointments, update own profile                     |

## Features List

### Authentication Features

- ✅ Register (`POST /api/v1/auth/signup`) — implemented with password hashing (`bcryptjs`) and JWT issuance
- ✅ Login (`POST /api/v1/auth/signin`) — implemented, verifies credentials and issues a JWT

### Authorization Features

- ✅ Protect specific routes based on login status — implemented via `middlewares/protect.js`, applied to the doctor-management write routes (create/update/delete)
- ✅ Admin dashboard — implemented in the Angular client (`/admin`), showing appointment counters, revenue and the queue waiting for confirmation
- ✅ Role-based access control — implemented via `middlewares/restrict-to.js`; doctor management is `admin` only, booking is `patient` only, user management is `admin` only
- ✅ Different permissions per user type — `GET /api/v1/appointments` answers differently for admin, doctor and patient, and status changes are limited per role

### CRUD Features

#### Doctors Management (implemented in this delivery)

**Create**
- Add a new doctor (with profile image)

**Read**
- View all doctors
- View a single doctor's details

**Update**
- Edit doctor information (including replacing the profile image)

**Delete**
- Remove a doctor (and their stored image)

#### Patients / Users Management (implemented)

- View every account, filter by role, change a user's role, delete an account
- Every user edits their own profile (name, phone, photo) from `/profile`

#### Appointments Management (implemented)

- Book a visit (patient), with server-side checks on the date, the doctor's
  clinic days and double booking
- View visits — admin sees all, a doctor sees their own schedule, a patient
  sees their own bookings
- Confirm / complete / cancel a visit, and delete one (admin)

## Image / File Upload Features

| Upload               | Allowed types                  | Max size | Uploaded by                          |
| -------------------- | ------------------------------ | -------- | ------------------------------------ |
| Doctor profile image | JPG, PNG, WEBP (any `image/*`) | 5 MB     | Admin (when adding/editing a doctor) |
| User profile photo   | JPG, PNG, WEBP (any `image/*`) | 5 MB     | Every user (signup or profile page)  |

## UI Design

The screens were built directly as the Angular client in `hospital-frontend`:
Home, Doctors list (card and list view), Doctor details, Login, Register,
Book a visit, My appointments, Doctor schedule, Profile, Admin dashboard,
Manage doctors, Add/Edit doctor, Manage appointments, Manage users, and a
not-found page.

## Learning Objectives Covered

- Analyzed the application idea before coding.
- Identified system users and permissions.
- Planned CRUD operations for the Doctor entity.
- Implemented authentication (JWT + bcrypt), route protection and role-based
  authorization.
- Converted the idea into a full-stack application: an Express/MongoDB API and
  an Angular client.
