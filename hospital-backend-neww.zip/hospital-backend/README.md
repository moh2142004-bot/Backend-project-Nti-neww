# Smart Hospital Management System — Backend

Node.js + Express + MongoDB (Mongoose) REST API for a hospital that lets
**patients** book appointments with **doctors**, while **doctors** manage the
visits booked with them and an **admin** manages the whole system.

The Angular client that consumes this API lives in `../hospital-frontend`.

---

## 👥 Roles

| Role    | Can do                                                                  |
| ------- | ----------------------------------------------------------------------- |
| Admin   | Manage doctors, manage every appointment, manage user accounts and roles |
| Doctor  | See the visits booked with them, confirm / complete / cancel them        |
| Patient | Browse doctors, book a visit, cancel their own visit, edit their profile |

Roles are enforced twice: `protect` checks the JWT, then `restrictTo(...)`
checks the role. The client guards only hide pages — the server is what decides.

---

## 🧱 Modules

### 1. Doctors (entity module + file upload)

| Method | Route                 | Access | Description                                  |
| ------ | --------------------- | ------ | -------------------------------------------- |
| GET    | `/api/v1/doctors`     | Public | All doctors (`?specialization=`, `?search=`) |
| GET    | `/api/v1/doctors/:id` | Public | One doctor                                   |
| POST   | `/api/v1/doctors`     | Admin  | Add a doctor (+ profile image)               |
| PATCH  | `/api/v1/doctors/:id` | Admin  | Update a doctor (+ replace image)            |
| DELETE | `/api/v1/doctors/:id` | Admin  | Remove a doctor, their image and their visits |

Doctor fields: `name`, `email` (unique), `phone`, `specialization` (enum),
`bio`, `experienceYears`, `consultationFee`, `availableDays` (array of week
days), `profileImage`, `user` (optional link to a user account with the
`doctor` role), plus `createdAt` / `updatedAt`.

### 2. Authentication (bcrypt + JWT)

| Method | Route                 | Access    | Description                                  |
| ------ | --------------------- | --------- | -------------------------------------------- |
| POST   | `/api/v1/auth/signup` | Public    | Register (+ optional photo), returns a token |
| POST   | `/api/v1/auth/signin` | Public    | Log in, returns a token                      |
| GET    | `/api/v1/auth/me`     | Logged in | The current user (example protected route)   |

Signup only accepts `patient` or `doctor` as a role — an admin cannot be
created from the public form. Passwords are hashed in a `pre("save")` hook and
the field is `select: false`.

### 3. Users

| Method | Route               | Access    | Description                                   |
| ------ | ------------------- | --------- | --------------------------------------------- |
| GET    | `/api/v1/users`     | Admin     | All accounts (`?role=doctor`)                 |
| GET    | `/api/v1/users/me`  | Logged in | My account                                    |
| PATCH  | `/api/v1/users/me`  | Logged in | Update my name / phone / photo                |
| PATCH  | `/api/v1/users/:id` | Admin     | Change a user's role                          |
| DELETE | `/api/v1/users/:id` | Admin     | Delete a user (and unlink any doctor profile) |

An admin can neither change nor delete their own account from these routes.

### 4. Appointments

| Method | Route                               | Access         | Description                      |
| ------ | ----------------------------------- | -------------- | -------------------------------- |
| GET    | `/api/v1/appointments/availability` | Public         | Free slots of a doctor on a date |
| GET    | `/api/v1/appointments`              | Logged in      | Admin: all · Doctor: their schedule · Patient: their bookings |
| GET    | `/api/v1/appointments/stats`        | Admin          | Dashboard counters + revenue     |
| POST   | `/api/v1/appointments`              | Patient        | Book a visit                     |
| GET    | `/api/v1/appointments/:id`          | Owner or admin | One visit                        |
| PATCH  | `/api/v1/appointments/:id`          | Owner or admin | Change status                    |
| DELETE | `/api/v1/appointments/:id`          | Admin          | Delete a visit                   |

Booking rules enforced on the server:

- the doctor must exist;
- the date cannot be in the past;
- the doctor must actually work on that week day (`availableDays`);
- the slot must be one of the clinic hours (09:00 → 17:00, on the hour);
- the same doctor cannot have two active visits in the same slot (409);
- the fee is copied from the doctor, never sent by the client.

Status rules: a patient may only **cancel** their own visit; a doctor may move
the visits booked with them between `pending`, `confirmed`, `completed` and
`cancelled`; an admin may do both and delete.

---

## 📁 File upload (Multer)

- Doctor photo → field `profileImage` → saved in `uploads/doctors/`
- User photo → field `imageUrl` → saved in `uploads/users/`
- Images only (`fileFilter`), maximum **5 MB**
- Only the file name is stored in MongoDB
- Orphan files are deleted when validation fails, when a photo is replaced and
  when the owning document is removed
- Served at `http://localhost:3000/api/v1/uploads/<folder>/<filename>`

When sending a file, use **form-data** (not JSON). For `availableDays`, add one
row per day (or a comma separated string — both are accepted).

---

## ⚙️ Run it locally

```bash
npm install
```

Create a `.env` file in the project root (copy `.env.example`):

```env
PORT=3000
MONGODB_URI=mongodb+srv://<username>:<password>@cluster.mongodb.net/
DB_NAME=Hospital-Management-System
JWT_SECRET=<a long random string>
JWT_EXPIRES_IN=7d
```

Generate a good secret with:

```bash
node -e "console.log(require('crypto').randomBytes(32).toString('hex'))"
```

Fill the database with demo data (run once):

```bash
npm run seed
```

It creates:

| Account              | Password     | Role    |
| -------------------- | ------------ | ------- |
| admin@hospital.com   | admin12345   | admin   |
| patient@hospital.com | patient12345 | patient |

plus six doctors across the six departments.

Start the server:

```bash
npm start
```

The API is then on `http://localhost:3000/api/v1`.

---

## 🗂️ Structure

```
hospital-backend/
├── config/db-connect.js
├── controllers/
│   ├── appointment-controllers.js
│   ├── auth-controllers.js
│   ├── doctor-controllers.js
│   └── user-controllers.js
├── middlewares/
│   ├── protect.js          JWT check
│   ├── restrict-to.js      role check
│   └── upload.js           multer
├── models/
│   ├── appointment-model.js
│   ├── doctor-model.js
│   └── user-model.js
├── routes/
│   ├── appointment-routes.js
│   ├── auth-routes.js
│   ├── doctor-routes.js
│   └── user-routes.js
├── utils/
│   ├── delete-uploaded-file.js
│   ├── get-jwt.js
│   ├── seed.js
│   └── time-slots.js
├── uploads/{doctors,users}/
├── .env.example
├── index.js
└── package.json
```

---

## 🧪 Testing with Postman

1. `POST /api/v1/auth/signin` with `admin@hospital.com` / `admin12345`, copy
   the `token` from the response.
2. In **Authorization → Bearer Token**, paste it, then try
   `POST /api/v1/doctors` with **form-data** (including a `profileImage` file).
3. Sign in as the patient and `POST /api/v1/appointments` with JSON:
   `{ "doctor": "<doctorId>", "date": "2026-10-03", "timeSlot": "10:00" }`.
4. Repeat the same booking — you should get `409 Conflict`.
5. Call an admin route with the patient token — you should get `403 Forbidden`.
6. Call a protected route without a token — you should get `401 Unauthorized`.

---

## ✅ Error handling

Every failure answers with JSON: invalid route (404), invalid JSON body (400),
upload too large or of the wrong type (400), not found (404), missing token
(401), wrong role (403), duplicate booking (409), validation errors (400).
