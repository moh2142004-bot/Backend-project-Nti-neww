const Appointment = require("../models/appointment-model");
const Doctor = require("../models/doctor-model");
const TIME_SLOTS = require("../utils/time-slots");

const WEEK_DAYS = [
  "sunday",
  "monday",
  "tuesday",
  "wednesday",
  "thursday",
  "friday",
  "saturday",
];

// Build the mongoose filter for the logged in user:
// admin   -> every appointment
// doctor  -> only the appointments of the doctor profile linked to his account
// patient -> only his own appointments
const buildAccessFilter = async (user) => {
  if (user.role === "admin") return {};

  if (user.role === "doctor") {
    const doctorProfile = await Doctor.findOne({ user: user._id });
    // No linked profile yet => no appointments at all.
    return { doctor: doctorProfile ? doctorProfile._id : null };
  }

  return { patient: user._id };
};

// GET /api/v1/appointments
const getAllAppointments = async (req, res) => {
  try {
    const filter = await buildAccessFilter(req.user);

    if (req.query.status) filter.status = req.query.status;
    if (req.query.doctor && req.user.role === "admin") {
      filter.doctor = req.query.doctor;
    }

    const appointments = await Appointment.find(filter)
      .populate("doctor", "name specialization profileImage consultationFee")
      .populate("patient", "name email phone imageUrl")
      .sort({ date: 1, timeSlot: 1 });

    res.status(200).json({
      status: "success",
      count: appointments.length,
      data: { appointments },
    });
  } catch (error) {
    res.status(400).json({
      status: "error",
      message: `Failed to fetch appointments: ${error.message}`,
    });
  }
};

// GET /api/v1/appointments/:id
const getAppointmentById = async (req, res) => {
  try {
    const appointment = await Appointment.findById(req.params.id)
      .populate("doctor", "name specialization profileImage consultationFee")
      .populate("patient", "name email phone imageUrl");

    if (!appointment) {
      return res.status(404).json({
        status: "fail",
        message: "Appointment not found",
      });
    }

    const filter = await buildAccessFilter(req.user);
    const isOwner =
      req.user.role === "admin" ||
      (filter.patient &&
        String(appointment.patient._id) === String(filter.patient)) ||
      (filter.doctor &&
        String(appointment.doctor._id) === String(filter.doctor));

    if (!isOwner) {
      return res.status(403).json({
        status: "fail",
        message: "You do not have permission to view this appointment",
      });
    }

    res.status(200).json({ status: "success", data: { appointment } });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};

// GET /api/v1/appointments/availability?doctor=<id>&date=<YYYY-MM-DD>
// Public helper used by the booking form to disable already taken slots.
const getDoctorAvailability = async (req, res) => {
  try {
    const { doctor: doctorId, date } = req.query;

    if (!doctorId || !date) {
      return res.status(400).json({
        status: "fail",
        message: "Doctor id and date are required",
      });
    }

    const doctor = await Doctor.findById(doctorId);
    if (!doctor) {
      return res.status(404).json({
        status: "fail",
        message: "Doctor not found",
      });
    }

    const day = new Date(date);
    if (Number.isNaN(day.getTime())) {
      return res.status(400).json({
        status: "fail",
        message: "Please provide a valid date",
      });
    }

    const weekDay = WEEK_DAYS[day.getUTCDay()];
    const worksThatDay =
      doctor.availableDays.length === 0 || doctor.availableDays.includes(weekDay);

    const startOfDay = new Date(`${date}T00:00:00.000Z`);
    const endOfDay = new Date(`${date}T23:59:59.999Z`);

    const booked = await Appointment.find({
      doctor: doctorId,
      date: { $gte: startOfDay, $lte: endOfDay },
      status: { $ne: "cancelled" },
    }).select("timeSlot");

    const takenSlots = booked.map((appointment) => appointment.timeSlot);

    res.status(200).json({
      status: "success",
      data: {
        weekDay,
        worksThatDay,
        allSlots: TIME_SLOTS,
        takenSlots,
        availableSlots: worksThatDay
          ? TIME_SLOTS.filter((slot) => !takenSlots.includes(slot))
          : [],
      },
    });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};

// POST /api/v1/appointments   (patients only)
const createAppointment = async (req, res) => {
  try {
    const { doctor: doctorId, date, timeSlot, reason } = req.body;

    if (!doctorId || !date || !timeSlot) {
      return res.status(400).json({
        status: "fail",
        message: "Doctor, date and time slot are required",
      });
    }

    const doctor = await Doctor.findById(doctorId);
    if (!doctor) {
      return res.status(404).json({
        status: "fail",
        message: "Doctor not found",
      });
    }

    const appointmentDate = new Date(date);
    if (Number.isNaN(appointmentDate.getTime())) {
      return res.status(400).json({
        status: "fail",
        message: "Please provide a valid date",
      });
    }

    const today = new Date();
    today.setHours(0, 0, 0, 0);
    if (appointmentDate < today) {
      return res.status(400).json({
        status: "fail",
        message: "You cannot book an appointment in the past",
      });
    }

    const weekDay = WEEK_DAYS[appointmentDate.getUTCDay()];
    if (
      doctor.availableDays.length > 0 &&
      !doctor.availableDays.includes(weekDay)
    ) {
      return res.status(400).json({
        status: "fail",
        message: `Dr. ${doctor.name} is not available on ${weekDay}`,
      });
    }

    const alreadyBooked = await Appointment.findOne({
      doctor: doctorId,
      date: appointmentDate,
      timeSlot,
      status: { $ne: "cancelled" },
    });

    if (alreadyBooked) {
      return res.status(409).json({
        status: "fail",
        message: "This time slot is already booked, please pick another one",
      });
    }

    const appointment = await Appointment.create({
      doctor: doctorId,
      patient: req.user._id,
      date: appointmentDate,
      timeSlot,
      reason,
      fee: doctor.consultationFee,
    });

    const populated = await appointment.populate([
      { path: "doctor", select: "name specialization profileImage consultationFee" },
      { path: "patient", select: "name email phone imageUrl" },
    ]);

    res.status(201).json({
      status: "success",
      message: "Appointment booked successfully",
      data: { appointment: populated },
    });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};

// PATCH /api/v1/appointments/:id
// Patient can only cancel his own appointment.
// Doctor and admin can move it between pending / confirmed / completed / cancelled.
const updateAppointmentStatus = async (req, res) => {
  try {
    const { status } = req.body;

    const allowed = ["pending", "confirmed", "completed", "cancelled"];
    if (!allowed.includes(status)) {
      return res.status(400).json({
        status: "fail",
        message: "Status must be pending, confirmed, completed or cancelled",
      });
    }

    const appointment = await Appointment.findById(req.params.id);
    if (!appointment) {
      return res.status(404).json({
        status: "fail",
        message: "Appointment not found",
      });
    }

    const filter = await buildAccessFilter(req.user);

    if (req.user.role === "patient") {
      if (String(appointment.patient) !== String(req.user._id)) {
        return res.status(403).json({
          status: "fail",
          message: "You can only update your own appointments",
        });
      }

      if (status !== "cancelled") {
        return res.status(403).json({
          status: "fail",
          message: "Patients can only cancel their appointments",
        });
      }
    }

    if (req.user.role === "doctor") {
      if (
        !filter.doctor ||
        String(appointment.doctor) !== String(filter.doctor)
      ) {
        return res.status(403).json({
          status: "fail",
          message: "You can only update appointments booked with you",
        });
      }
    }

    appointment.status = status;
    const updated = await appointment.save();

    const populated = await updated.populate([
      { path: "doctor", select: "name specialization profileImage consultationFee" },
      { path: "patient", select: "name email phone imageUrl" },
    ]);

    res.status(200).json({
      status: "success",
      message: "Appointment updated successfully",
      data: { appointment: populated },
    });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};

// DELETE /api/v1/appointments/:id   (admin only)
const deleteAppointment = async (req, res) => {
  try {
    const deleted = await Appointment.findByIdAndDelete(req.params.id);

    if (!deleted) {
      return res.status(404).json({
        status: "fail",
        message: "Appointment not found",
      });
    }

    res.status(200).json({
      status: "success",
      message: "Appointment deleted successfully",
      data: { appointment: deleted },
    });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};

// GET /api/v1/appointments/stats   (admin only) - used by the dashboard
const getAppointmentStats = async (req, res) => {
  try {
    const [total, pending, confirmed, completed, cancelled, doctors] =
      await Promise.all([
        Appointment.countDocuments(),
        Appointment.countDocuments({ status: "pending" }),
        Appointment.countDocuments({ status: "confirmed" }),
        Appointment.countDocuments({ status: "completed" }),
        Appointment.countDocuments({ status: "cancelled" }),
        Doctor.countDocuments(),
      ]);

    const revenue = await Appointment.aggregate([
      { $match: { status: "completed" } },
      { $group: { _id: null, total: { $sum: "$fee" } } },
    ]);

    res.status(200).json({
      status: "success",
      data: {
        stats: {
          total,
          pending,
          confirmed,
          completed,
          cancelled,
          doctors,
          revenue: revenue.length ? revenue[0].total : 0,
        },
      },
    });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};

module.exports = {
  getAllAppointments,
  getAppointmentById,
  getDoctorAvailability,
  createAppointment,
  updateAppointmentStatus,
  deleteAppointment,
  getAppointmentStats,
};
