const Doctor = require("../models/doctor-model");
const Appointment = require("../models/appointment-model");
const deleteUploadedFile = require("../utils/delete-uploaded-file");

// With form-data, "availableDays" arrives either as a single string,
// as an array, or as a comma separated string. Normalize all of them.
const normalizeAvailableDays = (days) => {
  if (!days) return [];
  if (Array.isArray(days)) return days.map((day) => day.toLowerCase().trim());
  return days
    .split(",")
    .map((day) => day.toLowerCase().trim())
    .filter((day) => day.length > 0);
};

// An empty string coming from a <select> must be stored as null,
// otherwise mongoose tries to cast "" into an ObjectId and throws.
const normalizeUser = (user) => (user ? user : null);

// Get all doctors
const getAllDoctors = async (req, res) => {
  try {
    const filter = {};

    if (req.query.specialization) {
      filter.specialization = req.query.specialization.toLowerCase();
    }

    if (req.query.search) {
      filter.name = { $regex: req.query.search, $options: "i" };
    }

    const doctors = await Doctor.find(filter)
      .populate("user", "name email")
      .sort({ createdAt: -1 });

    res.status(200).json({
      status: "success",
      count: doctors.length,
      data: {
        doctors,
      },
    });
  } catch (error) {
    res.status(400).json({
      status: "error",
      message: `Failed to fetch doctors: ${error.message}`,
    });
  }
};

// Create doctor
const createDoctor = async (req, res) => {
  try {
    const specialization = req.body.specialization?.toLowerCase();

    const newDoctor = await Doctor.create({
      ...req.body,
      specialization,
      availableDays: normalizeAvailableDays(req.body.availableDays),
      user: normalizeUser(req.body.user),
      profileImage: req.file?.filename,
    });

    res.status(201).json({
      status: "success",
      message: "Doctor added successfully",
      data: {
        doctor: newDoctor,
      },
    });
  } catch (error) {
    if (req.file) {
      deleteUploadedFile("doctors", req.file.filename);
    }
    res.status(400).json({
      status: "error",
      message: error.message,
    });
  }
};

// Get doctor by ID
const getDoctorById = async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.params.id).populate(
      "user",
      "name email"
    );

    if (!doctor) {
      return res.status(404).json({
        status: "fail",
        message: "Doctor not found",
      });
    }

    res.status(200).json({
      status: "success",
      data: {
        doctor,
      },
    });
  } catch (error) {
    res.status(400).json({
      status: "error",
      message: error.message,
    });
  }
};

// Update doctor
const updateDoctor = async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.params.id);

    if (!doctor) {
      return res.status(404).json({
        status: "fail",
        message: "Doctor not found",
      });
    }

    if (req.body.specialization) {
      req.body.specialization = req.body.specialization.toLowerCase();
    }

    if (req.body.availableDays !== undefined) {
      req.body.availableDays = normalizeAvailableDays(req.body.availableDays);
    }

    if (req.body.user !== undefined) {
      req.body.user = normalizeUser(req.body.user);
    }

    if (req.file) {
      req.body.profileImage = req.file.filename;
      if (doctor.profileImage) deleteUploadedFile("doctors", doctor.profileImage);
    }

    Object.assign(doctor, req.body);

    const updatedDoctor = await doctor.save();

    res.status(200).json({
      status: "success",
      message: "Doctor updated successfully",
      data: {
        doctor: updatedDoctor,
      },
    });
  } catch (error) {
    if (req.file) {
      deleteUploadedFile("doctors", req.file.filename);
    }
    res.status(400).json({
      status: "error",
      message: error.message,
    });
  }
};

// Delete doctor
const deleteDoctor = async (req, res) => {
  try {
    const deletedDoctor = await Doctor.findByIdAndDelete(req.params.id);

    if (!deletedDoctor) {
      return res.status(404).json({
        status: "fail",
        message: "Doctor not found",
      });
    }

    if (deletedDoctor.profileImage) {
      deleteUploadedFile("doctors", deletedDoctor.profileImage);
    }

    // Remove the appointments that were booked with this doctor.
    await Appointment.deleteMany({ doctor: deletedDoctor._id });

    res.status(200).json({
      status: "success",
      message: "Doctor deleted successfully",
      data: {
        doctor: deletedDoctor,
      },
    });
  } catch (error) {
    res.status(400).json({
      status: "error",
      message: error.message,
    });
  }
};

module.exports = {
  getAllDoctors,
  createDoctor,
  getDoctorById,
  updateDoctor,
  deleteDoctor,
};
