const Review = require("../models/review-model");
const Doctor = require("../models/doctor-model");

const refreshDoctorRating = async (doctorId) => {
  const summary = await Review.aggregate([
    { $match: { doctor: doctorId } },
    {
      $group: {
        _id: "$doctor",
        average: { $avg: "$rating" },
        count: { $sum: 1 },
      },
    },
  ]);

  const average = summary[0]?.average ?? 0;
  const count = summary[0]?.count ?? 0;

  await Doctor.findByIdAndUpdate(doctorId, {
    rating: Number(average.toFixed(1)),
    reviewCount: count,
  });
};

const getDoctorReviews = async (req, res) => {
  try {
    const reviews = await Review.find({ doctor: req.params.id })
      .populate("patient", "name")
      .sort({ createdAt: -1 });

    res.status(200).json({
      status: "success",
      count: reviews.length,
      data: { reviews },
    });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};

const createReview = async (req, res) => {
  try {
    const doctor = await Doctor.findById(req.params.id);
    if (!doctor) {
      return res.status(404).json({ status: "fail", message: "Doctor not found" });
    }

    const review = await Review.create({
      doctor: doctor._id,
      patient: req.user._id,
      rating: Number(req.body.rating),
      comment: req.body.comment,
    });

    await refreshDoctorRating(doctor._id);
    const populated = await review.populate("patient", "name");

    res.status(201).json({
      status: "success",
      message: "Thank you for your review",
      data: { review: populated },
    });
  } catch (error) {
    const duplicate = error.code === 11000;
    res.status(duplicate ? 409 : 400).json({
      status: duplicate ? "fail" : "error",
      message: duplicate ? "You have already reviewed this doctor" : error.message,
    });
  }
};

const toggleReviewLike = async (req, res) => {
  try {
    const review = await Review.findById(req.params.reviewId);
    if (!review) {
      return res.status(404).json({ status: "fail", message: "Review not found" });
    }

    const userId = req.user._id.toString();
    const index = review.likes.findIndex((id) => id.toString() === userId);

    if (index >= 0) {
      review.likes.splice(index, 1);
    } else {
      review.likes.push(req.user._id);
    }

    await review.save();

    res.status(200).json({
      status: "success",
      data: { liked: index < 0, likesCount: review.likes.length },
    });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};

module.exports = { getDoctorReviews, createReview, toggleReviewLike, refreshDoctorRating };
