const User = require("../models/user-model");
const Doctor = require("../models/doctor-model");
const deleteUploadedFile = require("../utils/delete-uploaded-file");

// GET /api/v1/users            (admin only)
// Optional filter: /api/v1/users?role=doctor
const getAllUsers = async (req, res) => {
  try {
    const filter = {};
    if (req.query.role) filter.role = req.query.role;

    const users = await User.find(filter).sort({ createdAt: -1 });

    res.status(200).json({
      status: "success",
      count: users.length,
      data: { users },
    });
  } catch (error) {
    res.status(400).json({
      status: "error",
      message: `Failed to fetch users: ${error.message}`,
    });
  }
};

// GET /api/v1/users/me
const getMe = async (req, res) => {
  res.status(200).json({
    status: "success",
    data: { user: req.user },
  });
};

// PATCH /api/v1/users/me
// The logged in user updates his own profile (name, phone, photo).
const updateMe = async (req, res) => {
  try {
    const user = await User.findById(req.user._id);

    if (!user) {
      return res.status(404).json({
        status: "fail",
        message: "User not found",
      });
    }

    // Role and password are never updated from here.
    const { name, phone } = req.body;
    if (name !== undefined) user.name = name;
    if (phone !== undefined) user.phone = phone;

    if (req.file) {
      const oldImage = user.imageUrl;
      user.imageUrl = req.file.filename;
      if (oldImage) deleteUploadedFile("users", oldImage);
    }

    const updatedUser = await user.save();

    res.status(200).json({
      status: "success",
      message: "Profile updated successfully",
      data: { user: updatedUser },
    });
  } catch (error) {
    if (req.file) deleteUploadedFile("users", req.file.filename);
    res.status(400).json({ status: "error", message: error.message });
  }
};

// PATCH /api/v1/users/:id      (admin only) - change a user role
const updateUserRole = async (req, res) => {
  try {
    const { role } = req.body;

    if (!["admin", "doctor", "patient"].includes(role)) {
      return res.status(400).json({
        status: "fail",
        message: "Role must be admin, doctor or patient",
      });
    }

    if (String(req.params.id) === String(req.user._id)) {
      return res.status(400).json({
        status: "fail",
        message: "You cannot change your own role",
      });
    }

    const user = await User.findByIdAndUpdate(
      req.params.id,
      { role },
      { returnDocument: "after", runValidators: true }
    );

    if (!user) {
      return res.status(404).json({
        status: "fail",
        message: "User not found",
      });
    }

    res.status(200).json({
      status: "success",
      message: "User role updated successfully",
      data: { user },
    });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};

// DELETE /api/v1/users/:id     (admin only)
const deleteUser = async (req, res) => {
  try {
    if (String(req.params.id) === String(req.user._id)) {
      return res.status(400).json({
        status: "fail",
        message: "You cannot delete your own account",
      });
    }

    const deletedUser = await User.findByIdAndDelete(req.params.id);

    if (!deletedUser) {
      return res.status(404).json({
        status: "fail",
        message: "User not found",
      });
    }

    // Unlink the deleted account from any doctor profile.
    await Doctor.updateMany({ user: deletedUser._id }, { user: null });

    if (deletedUser.imageUrl) {
      deleteUploadedFile("users", deletedUser.imageUrl);
    }

    res.status(200).json({
      status: "success",
      message: "User deleted successfully",
      data: { user: deletedUser },
    });
  } catch (error) {
    res.status(400).json({ status: "error", message: error.message });
  }
};

module.exports = {
  getAllUsers,
  getMe,
  updateMe,
  updateUserRole,
  deleteUser,
};
