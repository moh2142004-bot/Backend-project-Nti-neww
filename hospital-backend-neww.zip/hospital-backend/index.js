const dns = require("dns");
dns.setServers(["8.8.8.8", "8.8.4.4"]);

const express = require("express");
const path = require("path");
const cors = require("cors");
const multer = require("multer");
require("dotenv").config();

const dbConnect = require("./config/db-connect");
const doctorRouter = require("./routes/doctor-routes");
const authRouter = require("./routes/auth-routes");
const userRouter = require("./routes/user-routes");
const appointmentRouter = require("./routes/appointment-routes");
const reviewRouter = require("./routes/review-routes");

dbConnect();

const app = express();

// Allow the Angular app (http://localhost:4200) to call this API.
app.use(cors());

app.use(express.json());

// Serve uploaded images statically
app.use("/api/v1/uploads", express.static(path.join(__dirname, "uploads")));

app.use("/api/v1/doctors", doctorRouter);
app.use("/api/v1/auth", authRouter);
app.use("/api/v1/users", userRouter);
app.use("/api/v1/appointments", appointmentRouter);
app.use("/api/v1/doctors/:id/reviews", reviewRouter);

// Invalid route
app.use((req, res) => {
  res.status(404).json({
    status: "fail",
    message: `Route ${req.originalUrl} is not available on this server`,
  });
});

// Global error handler (invalid JSON body, multer upload errors, ...)
app.use((error, req, res, next) => {
  if (error instanceof multer.MulterError) {
    const message =
      error.code === "LIMIT_FILE_SIZE"
        ? "Image is too large, maximum allowed size is 5 MB"
        : `Upload error: ${error.message}`;

    return res.status(400).json({ status: "fail", message });
  }

  if (error.type === "entity.parse.failed") {
    return res.status(400).json({
      status: "fail",
      message: "Invalid JSON in the request body",
    });
  }

  res.status(error.status || 500).json({
    status: "error",
    message: error.message || "Something went wrong on the server",
  });
});

app.listen(process.env.PORT, () => {
  console.log(`Server listening on port ${process.env.PORT}`);
});
