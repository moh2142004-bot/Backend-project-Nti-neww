const multer = require("multer");
const fs = require("fs");

const diskStorage = multer.diskStorage({
  destination: function (req, file, cb) {
    let dest = "uploads";

    if (req.baseUrl.includes("doctors")) {
      dest = "uploads/doctors";
    } else if (req.baseUrl.includes("auth") || req.baseUrl.includes("users")) {
      dest = "uploads/users";
    }

    try {
      fs.mkdirSync(dest, { recursive: true });
      cb(null, dest);
    } catch (err) {
      cb(err, null);
    }
  },

  filename: function (req, file, cb) {
    let fileName = file.originalname;
    let fileType = file.mimetype.split("/")[1];

    if (req.baseUrl.includes("doctors")) {
      fileName = `doctor-${Date.now()}.${fileType}`;
    } else if (req.baseUrl.includes("auth") || req.baseUrl.includes("users")) {
      fileName = `user-${Date.now()}.${fileType}`;
    }

    cb(null, fileName);
  },
});

const fileFilter = (req, file, cb) => {
  const fileType = file.mimetype.split("/")[0];

  if (fileType == "image") {
    cb(null, true);
  } else {
    cb(new Error("Only images are allowed"), false);
  }
};

const upload = multer({
  storage: diskStorage,
  fileFilter,
  limits: { fileSize: 5 * 1024 * 1024 }, // 5 MB per image
});

module.exports = upload;
