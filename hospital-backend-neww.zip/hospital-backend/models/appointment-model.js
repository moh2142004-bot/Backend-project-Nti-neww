const mongoose = require("mongoose");
const TIME_SLOTS = require("../utils/time-slots");

const appointmentSchema = new mongoose.Schema(
  {
    doctor: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "Doctor",
      required: [true, "Doctor is required"],
    },

    patient: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      required: [true, "Patient is required"],
    },

    date: {
      type: Date,
      required: [true, "Appointment date is required"],
    },

    timeSlot: {
      type: String,
      required: [true, "Appointment time is required"],
      enum: {
        values: TIME_SLOTS,
        message: "Please provide a valid time slot",
      },
    },

    reason: {
      type: String,
      trim: true,
      maxlength: [500, "Reason cannot exceed 500 characters"],
    },

    status: {
      type: String,
      enum: {
        values: ["pending", "confirmed", "completed", "cancelled"],
        message: "Status must be pending, confirmed, completed or cancelled",
      },
      default: "pending",
    },

    fee: {
      type: Number,
      min: [0, "Fee cannot be negative"],
      default: 0,
    },
  },
  {
    timestamps: true,
  }
);

// Prevent booking the same doctor twice in the same day + time slot
appointmentSchema.index({ doctor: 1, date: 1, timeSlot: 1 });

const Appointment = mongoose.model("Appointment", appointmentSchema);

module.exports = Appointment;
