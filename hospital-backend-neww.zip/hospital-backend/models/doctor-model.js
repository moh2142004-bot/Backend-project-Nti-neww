const mongoose = require("mongoose");

const doctorSchema = new mongoose.Schema(
  {
    name: {
      type: String,
      required: [true, "Doctor name is required"],
      trim: true,
      minlength: [3, "Doctor name must be at least 3 characters long"],
      maxlength: [100, "Doctor name cannot exceed 100 characters"],
    },

    email: {
      type: String,
      required: [true, "Email is required"],
      unique: true,
      trim: true,
    },

    phone: {
      type: String,
      required: [true, "Phone number is required"],
      trim: true,
    },

    specialization: {
      type: String,
      required: [true, "Specialization is required"],
      trim: true,
      enum: {
        values: [
          "cardiology",
          "dermatology",
          "pediatrics",
          "orthopedics",
          "neurology",
          "general",
        ],
        message: "Please provide a valid specialization",
      },
    },

    location: {
      type: String,
      trim: true,
      default: "Cairo",
    },

    bio: {
      type: String,
      trim: true,
      maxlength: [1000, "Bio cannot exceed 1000 characters"],
    },

    experienceYears: {
      type: Number,
      required: [true, "Years of experience is required"],
      min: [0, "Experience years cannot be negative"],
    },

    consultationFee: {
      type: Number,
      required: [true, "Consultation fee is required"],
      min: [0, "Consultation fee cannot be negative"],
      default: 0,
    },

    isFeatured: {
      type: Boolean,
      default: false,
    },

    rating: {
      type: Number,
      min: 0,
      max: 5,
      default: 0,
    },

    reviewCount: {
      type: Number,
      min: 0,
      default: 0,
    },

    availableDays: {
      type: [String],
      enum: {
        values: [
          "saturday",
          "sunday",
          "monday",
          "tuesday",
          "wednesday",
          "thursday",
          "friday",
        ],
        message: "Please provide valid available days",
      },
      default: [],
    },

    profileImage: {
      type: String,
      trim: true,
    },

    // Optional link to a user account with the "doctor" role,
    // so that doctor can log in and see their own schedule.
    user: {
      type: mongoose.Schema.Types.ObjectId,
      ref: "User",
      default: null,
    },
  },
  {
    timestamps: true,
  }
);

const Doctor = mongoose.model("Doctor", doctorSchema);

module.exports = Doctor;
