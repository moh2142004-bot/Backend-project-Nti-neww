const express = require("express");
const appointmentControllers = require("../controllers/appointment-controllers");
const protect = require("../middlewares/protect");
const restrictTo = require("../middlewares/restrict-to");

const router = express.Router();

// Public helper for the booking form (which slots are still free).
router.get("/availability", appointmentControllers.getDoctorAvailability);

// Everything below requires a valid token.
router.use(protect);

router.get(
  "/stats",
  restrictTo("admin"),
  appointmentControllers.getAppointmentStats
);

router
  .route("/")
  .get(appointmentControllers.getAllAppointments)
  .post(restrictTo("patient"), appointmentControllers.createAppointment);

router
  .route("/:id")
  .get(appointmentControllers.getAppointmentById)
  .patch(appointmentControllers.updateAppointmentStatus)
  .delete(restrictTo("admin"), appointmentControllers.deleteAppointment);

module.exports = router;
