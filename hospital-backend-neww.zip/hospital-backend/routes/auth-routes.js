const express = require("express");
const authControllers = require("../controllers/auth-controllers");
const upload = require("../middlewares/upload");
const protect = require("../middlewares/protect");

const router = express.Router();

router.post("/signup", upload.single("imageUrl"), authControllers.signup);
router.post("/signin", authControllers.signin);

// Example protected route (Session 6 requirement)
router.get("/me", protect, (req, res) => {
  res.status(200).json({
    status: "success",
    data: { user: req.user },
  });
});

module.exports = router;
