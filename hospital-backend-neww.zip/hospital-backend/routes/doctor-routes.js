const express = require("express");
const doctorControllers = require("../controllers/doctor-controllers");
const upload = require("../middlewares/upload");
const protect = require("../middlewares/protect");
const restrictTo = require("../middlewares/restrict-to");

const router = express.Router();

router
  .route("/")
  .get(doctorControllers.getAllDoctors)
  .post(
    protect,
    restrictTo("admin"),
    upload.single("profileImage"),
    doctorControllers.createDoctor
  );

router
  .route("/:id")
  .get(doctorControllers.getDoctorById)
  .patch(
    protect,
    restrictTo("admin"),
    upload.single("profileImage"),
    doctorControllers.updateDoctor
  )
  .delete(protect, restrictTo("admin"), doctorControllers.deleteDoctor);

module.exports = router;
