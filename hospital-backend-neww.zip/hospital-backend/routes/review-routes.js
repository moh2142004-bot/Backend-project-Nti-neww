const express = require("express");
const reviewControllers = require("../controllers/review-controllers");
const protect = require("../middlewares/protect");
const restrictTo = require("../middlewares/restrict-to");

const router = express.Router({ mergeParams: true });

router.get("/", reviewControllers.getDoctorReviews);
router.post("/", protect, restrictTo("patient"), reviewControllers.createReview);
router.post("/:reviewId/like", protect, restrictTo("patient"), reviewControllers.toggleReviewLike);

module.exports = router;
