const express = require("express");
const userControllers = require("../controllers/user-controllers");
const protect = require("../middlewares/protect");
const restrictTo = require("../middlewares/restrict-to");
const upload = require("../middlewares/upload");

const router = express.Router();

// Every user route requires a logged in user.
router.use(protect);

router
  .route("/me")
  .get(userControllers.getMe)
  .patch(upload.single("imageUrl"), userControllers.updateMe);

// Admin only from here.
router.use(restrictTo("admin"));

router.get("/", userControllers.getAllUsers);

router
  .route("/:id")
  .patch(userControllers.updateUserRole)
  .delete(userControllers.deleteUser);

module.exports = router;
