/**
 * Seed script.
 *
 * Creates the first admin account and a few sample doctors so the
 * Angular app has real data to show on the first run.
 *
 * Run it once with:  npm run seed
 */

const dns = require("dns");
dns.setServers(["8.8.8.8", "8.8.4.4"]);

require("dotenv").config();

const mongoose = require("mongoose");
const dbConnect = require("../config/db-connect");
const User = require("../models/user-model");
const Doctor = require("../models/doctor-model");

const sampleDoctors = [
  {
    name: "Magdy Yacoub",
    email: "magdy.yacoub@hospital.com",
    location: "Cairo",
    phone: "01001234567",
    specialization: "cardiology",
    bio: "Featured demo profile: a senior cardiology specialist focused on heart care, prevention and patient education.",
    experienceYears: 50,
    consultationFee: 0,
    isFeatured: true,
    profileImage: "magdy-yacoub.jpg",
    availableDays: ["saturday", "monday", "wednesday"],
  },
  {
    name: "Karim Adel",
    profileImage: "karim-adel.jpg",
    email: "karim.adel@hospital.com",
    location: "Cairo",
    phone: "01007654321",
    specialization: "dermatology",
    bio: "Dermatologist treating acne, eczema and cosmetic skin concerns.",
    experienceYears: 8,
    consultationFee: 300,
    availableDays: ["sunday", "tuesday", "thursday"],
  },
  {
    name: "Hala Mostafa",
    profileImage: "hala-mostafa.jpg",
    email: "hala.mostafa@hospital.com",
    location: "Giza",
    phone: "01112223334",
    specialization: "pediatrics",
    bio: "Pediatrician caring for newborns, children and adolescents.",
    experienceYears: 11,
    consultationFee: 250,
    availableDays: ["saturday", "sunday", "monday", "tuesday", "wednesday"],
  },
  {
    name: "Tarek Nabil",
    profileImage: "tarek-nabil.jpg",
    email: "tarek.nabil@hospital.com",
    location: "Cairo",
    phone: "01223334445",
    specialization: "orthopedics",
    bio: "Orthopedic surgeon specialised in sports injuries and joint replacement.",
    experienceYears: 17,
    consultationFee: 450,
    availableDays: ["monday", "wednesday", "thursday"],
  },
  {
    name: "Sara Ibrahim",
    profileImage: "sara-ibrahim.jpg",
    email: "sara.ibrahim@hospital.com",
    location: "Alexandria",
    phone: "01099887766",
    specialization: "neurology",
    bio: "Neurologist focused on headache disorders, epilepsy and stroke follow-up.",
    experienceYears: 9,
    consultationFee: 380,
    availableDays: ["sunday", "tuesday"],
  },
  {
    name: "Omar Sherif",
    profileImage: "omar-sherif.jpg",
    email: "omar.sherif@hospital.com",
    location: "Cairo",
    phone: "01066554433",
    specialization: "general",
    bio: "General practitioner handling everyday complaints and routine check-ups.",
    experienceYears: 6,
    consultationFee: 200,
    availableDays: [
      "saturday",
      "sunday",
      "monday",
      "tuesday",
      "wednesday",
      "thursday",
    ],
  },
  {
    name: "Ahmed Samir",
    profileImage: "ahmed-samir.jpg",
    email: "ahmed.samir@hospital.com",
    location: "Giza",
    phone: "01011112222",
    specialization: "cardiology",
    bio: "Cardiologist focused on hypertension, coronary disease and preventive heart care.",
    experienceYears: 12,
    consultationFee: 350,
    availableDays: ["saturday", "monday", "thursday"],
  },
  {
    name: "Youssef Hassan",
    profileImage: "youssef-hassan.jpg",
    email: "youssef.hassan@hospital.com",
    location: "Cairo",
    phone: "01022223333",
    specialization: "cardiology",
    bio: "Cardiology consultant with experience in ECG, chest pain and heart-failure follow-up.",
    experienceYears: 10,
    consultationFee: 375,
    availableDays: ["sunday", "tuesday", "wednesday"],
  },
  {
    name: "Mariam Adel",
    profileImage: "mariam-adel.jpg",
    email: "mariam.adel@hospital.com",
    location: "Alexandria",
    phone: "01033334444",
    specialization: "dermatology",
    bio: "Dermatologist specializing in acne, pigmentation and common skin conditions.",
    experienceYears: 7,
    consultationFee: 280,
    availableDays: ["saturday", "monday", "wednesday"],
  },
  {
    name: "Lina Mostafa",
    profileImage: "lina-mostafa.jpg",
    email: "lina.mostafa@hospital.com",
    location: "Cairo",
    phone: "01044445555",
    specialization: "dermatology",
    bio: "Dermatology specialist providing medical and cosmetic skin consultations.",
    experienceYears: 9,
    consultationFee: 320,
    availableDays: ["sunday", "tuesday", "thursday"],
  },
  {
    name: "Ahmed Khaled",
    profileImage: "ahmed-khaled.svg",
    email: "ahmed.khaled@hospital.com",
    location: "Giza",
    phone: "01055556666",
    specialization: "pediatrics",
    bio: "Pediatrician caring for infants, children and routine childhood conditions.",
    experienceYears: 8,
    consultationFee: 240,
    availableDays: ["saturday", "monday", "wednesday"],
  },
  {
    name: "Jana Hany",
    profileImage: "jana-hany.svg",
    email: "jana.hany@hospital.com",
    location: "Cairo",
    phone: "01066667777",
    specialization: "pediatrics",
    bio: "Pediatric specialist focused on newborn care, nutrition and child development.",
    experienceYears: 13,
    consultationFee: 300,
    availableDays: ["sunday", "tuesday", "thursday"],
  },
  {
    name: "Mohamed Emad",
    profileImage: "mohamed-emad.svg",
    email: "mohamed.emad@hospital.com",
    location: "Alexandria",
    phone: "01077778888",
    specialization: "orthopedics",
    bio: "Orthopedic specialist treating fractures, sports injuries and joint problems.",
    experienceYears: 15,
    consultationFee: 400,
    availableDays: ["saturday", "monday", "thursday"],
  },
  {
    name: "Yassin Omar",
    profileImage: "yassin-omar.svg",
    email: "yassin.omar@hospital.com",
    location: "Cairo",
    phone: "01088889999",
    specialization: "orthopedics",
    bio: "Orthopedic consultant with a focus on knee, shoulder and sports injuries.",
    experienceYears: 11,
    consultationFee: 380,
    availableDays: ["sunday", "tuesday", "wednesday"],
  },
  {
    name: "Nourhan Ali",
    profileImage: "nourhan-ali.svg",
    email: "nourhan.ali@hospital.com",
    location: "Giza",
    phone: "01111112222",
    specialization: "neurology",
    bio: "Neurologist specializing in migraine, epilepsy and neurological follow-up.",
    experienceYears: 10,
    consultationFee: 360,
    availableDays: ["saturday", "monday", "wednesday"],
  },
  {
    name: "Omar Mahmoud",
    profileImage: "omar-mahmoud.svg",
    email: "omar.mahmoud@hospital.com",
    location: "Cairo",
    phone: "01122223333",
    specialization: "neurology",
    bio: "Neurology specialist focused on headache disorders, nerve conditions and stroke care.",
    experienceYears: 12,
    consultationFee: 390,
    availableDays: ["sunday", "tuesday", "thursday"],
  },
  {
    name: "Amr Tarek",
    profileImage: "amr-tarek.svg",
    email: "amr.tarek@hospital.com",
    location: "Alexandria",
    phone: "01133334444",
    specialization: "general",
    bio: "General practitioner for routine check-ups, common illnesses and preventive care.",
    experienceYears: 7,
    consultationFee: 220,
    availableDays: ["saturday", "sunday", "monday", "wednesday"],
  },
  {
    name: "Salma Hassan",
    profileImage: "salma-hassan.svg",
    email: "salma.hassan@hospital.com",
    location: "Cairo",
    phone: "01144445555",
    specialization: "general",
    bio: "Family medicine doctor providing everyday consultations and health screening.",
    experienceYears: 9,
    consultationFee: 250,
    availableDays: ["tuesday", "wednesday", "thursday"],
  },
];

const seed = async () => {
  await dbConnect();

  // 1) Admin account
  const adminEmail = "admin@hospital.com";
  let admin = await User.findOne({ email: adminEmail });

  if (!admin) {
    admin = await User.create({
      name: "System Admin",
      email: adminEmail,
      password: "admin12345",
      role: "admin",
      phone: "01000000000",
    });
    console.log(`Admin created  ->  ${adminEmail} / admin12345`);
  } else {
    console.log(`Admin already exists  ->  ${adminEmail}`);
  }

  // 2) A demo patient
  const patientEmail = "patient@hospital.com";
  const patientExists = await User.findOne({ email: patientEmail });

  if (!patientExists) {
    await User.create({
      name: "Nour Hassan",
      email: patientEmail,
      password: "patient12345",
      role: "patient",
      phone: "01055555555",
    });
    console.log(`Patient created  ->  ${patientEmail} / patient12345`);
  } else {
    console.log(`Patient already exists  ->  ${patientEmail}`);
  }

  // 3) Sample doctors
  for (const doctor of sampleDoctors) {
    const exists = await Doctor.findOne({ email: doctor.email });

    if (!exists) {
      await Doctor.create(doctor);
      console.log(`Doctor created  ->  ${doctor.name}`);
    } else {
      // Keep the seeded demo doctor up to date when the seed is run again.
      const updates = {
        name: doctor.name,
        specialization: doctor.specialization,
        location: doctor.location,
        bio: doctor.bio,
        experienceYears: doctor.experienceYears,
        consultationFee: doctor.consultationFee,
        availableDays: doctor.availableDays,
      };
      if (doctor.profileImage) updates.profileImage = doctor.profileImage;
      if (doctor.isFeatured !== undefined) updates.isFeatured = doctor.isFeatured;
      await Doctor.updateOne({ _id: exists._id }, { $set: updates });
      console.log(`Doctor already exists  ->  ${doctor.name}`);
    }
  }

  // 4) Demo patient accounts used for realistic review examples.
  const reviewPatients = [
    { name: "Mariam Hassan", email: "mariam.patient@hospital.com", phone: "01070000001" },
    { name: "Omar Ali", email: "omar.patient@hospital.com", phone: "01070000002" },
    { name: "Sara Mostafa", email: "sara.patient@hospital.com", phone: "01070000003" },
    { name: "Youssef Ahmed", email: "youssef.patient@hospital.com", phone: "01070000004" },
  ];

  const Review = require("../models/review-model");
  const patients = [];
  for (const data of reviewPatients) {
    let patient = await User.findOne({ email: data.email });
    if (!patient) {
      patient = await User.create({ ...data, password: "patient12345", role: "patient" });
      console.log(`Review patient created -> ${data.email}`);
    }
    patients.push(patient);
  }

  // Seed public demo reviews, especially for the featured cardiologist.
  const magdy = await Doctor.findOne({ email: "magdy.yacoub@hospital.com" });
  const demoReviews = magdy
    ? [
        [magdy, patients[0], 5, "Excellent doctor. The consultation was clear, calm and very reassuring."],
        [magdy, patients[1], 5, "Very professional and kind. I appreciated the detailed explanation and advice."],
        [magdy, patients[2], 5, "A wonderful experience from start to finish. Highly recommended."],
      ]
    : [];

  const otherReviewData = [
    ["karim.adel@hospital.com", patients[3], 4, "Friendly and explained the treatment plan very clearly."],
    ["hala.mostafa@hospital.com", patients[0], 5, "Great with children and very patient."],
    ["tarek.nabil@hospital.com", patients[1], 4, "Professional consultation and useful follow-up advice."],
  ];

  for (const [doctor, patient, rating, comment] of demoReviews) {
    await Review.findOneAndUpdate(
      { doctor: doctor._id, patient: patient._id },
      { $setOnInsert: { doctor: doctor._id, patient: patient._id, rating, comment, likes: [] } },
      { upsert: true, new: true }
    );
  }

  for (const [email, patient, rating, comment] of otherReviewData) {
    const doctor = await Doctor.findOne({ email });
    if (!doctor) continue;
    await Review.findOneAndUpdate(
      { doctor: doctor._id, patient: patient._id },
      { $setOnInsert: { doctor: doctor._id, patient: patient._id, rating, comment, likes: [] } },
      { upsert: true, new: true }
    );
  }

  // Add a few demo likes so the social feedback UI is populated on first run.
  if (magdy) {
    const firstMagdyReview = await Review.findOne({ doctor: magdy._id, patient: patients[0]._id });
    if (firstMagdyReview) {
      firstMagdyReview.likes = [patients[1]._id, patients[2]._id, patients[3]._id];
      await firstMagdyReview.save();
    }
  }

  // Recalculate all doctor ratings after seeding reviews.
  const doctors = await Doctor.find();
  for (const doctor of doctors) {
    const summary = await Review.aggregate([
      { $match: { doctor: doctor._id } },
      { $group: { _id: "$doctor", average: { $avg: "$rating" }, count: { $sum: 1 } } },
    ]);
    await Doctor.updateOne(
      { _id: doctor._id },
      { $set: { rating: Number((summary[0]?.average ?? 0).toFixed(1)), reviewCount: summary[0]?.count ?? 0 } }
    );
  }

  await mongoose.connection.close();
  console.log("\nSeeding finished.");
  process.exit(0);
};

seed().catch(async (error) => {
  console.log(`Seeding failed: ${error.message}`);
  await mongoose.connection.close();
  process.exit(1);
});
