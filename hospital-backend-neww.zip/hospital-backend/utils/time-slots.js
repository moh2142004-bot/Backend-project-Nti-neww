// The clinic working hours. Every appointment must start on one of these slots.
const TIME_SLOTS = [
  "09:00",
  "10:00",
  "11:00",
  "12:00",
  "13:00",
  "14:00",
  "15:00",
  "16:00",
  "17:00",
];

module.exports = TIME_SLOTS;
